/**
 * BOLT Skill Resolver (v1.0.0)
 * Lógica industrial para seleção de especialidade técnica.
 * Migrado para bolt-engine-core/skills/. 🛡️🧠
 */

const path = require('path');

class SkillResolver {
  constructor() {
    this.extensionMap = {
      '.js': ['backend'],
      '.sql': ['db'],
      '.css': ['frontend'],
      '.html': ['frontend'],
      '.jsx': ['frontend'],
      '.tsx': ['frontend', 'backend'],
      '.json': ['backend', 'db']
    };
  }

  resolve(scope, action = '') {
    const resolvedSkills = new Set();
    if (scope && scope.startsWith('file:')) {
      const filePath = scope.split('file:')[1];
      const ext = path.extname(filePath).toLowerCase();
      if (this.extensionMap[ext]) this.extensionMap[ext].forEach(s => resolvedSkills.add(s));
    }
    const normalizedAction = action.toLowerCase();
    if (normalizedAction.includes('css') || normalizedAction.includes('ui')) resolvedSkills.add('frontend');
    if (normalizedAction.includes('sql') || normalizedAction.includes('db')) resolvedSkills.add('db');
    if (resolvedSkills.size === 0) resolvedSkills.add('backend');
    return Array.from(resolvedSkills);
  }
}

module.exports = new SkillResolver();

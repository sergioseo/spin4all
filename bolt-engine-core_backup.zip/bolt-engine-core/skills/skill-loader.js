/**
 * BOLT Skill Loader (v1.0.0)
 * Responsável pelo carregamento seguro de system.txt e manifest.json.
 * Migrado para bolt-engine-core/skills/. 🛡️🧠
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class SkillLoader {
  constructor() { this.skillsRoot = __dirname; }

  load(skillName) {
    const skillPath = path.join(this.skillsRoot, skillName);
    const manifestPath = path.join(skillPath, 'manifest.json');
    const systemPromptPath = path.join(skillPath, 'system.txt');

    if (!fs.existsSync(manifestPath) || !fs.existsSync(systemPromptPath)) {
      throw new Error(`[SKILL:LOADER] ❌ Skill '${skillName}' não encontrada.`);
    }

    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const systemPrompt = fs.readFileSync(systemPromptPath, 'utf8');

    const currentHash = this._calculateHash(systemPrompt);
    if (currentHash !== manifest.hash && process.env.BOLT_IGNORE_CHECKSUM !== 'true') {
      throw new Error(`CRITICAL_SECURITY_VIOLATION: Skill '${skillName}' tampered.`);
    }

    return { name: manifest.name, version: manifest.version, systemPrompt, manifest };
  }

  _calculateHash(content) { return crypto.createHash('sha256').update(content).digest('hex'); }
}

module.exports = new SkillLoader();

/**
 * 🛰️ BOLT Logger (Elite AI Governance)
 * Migrado para bolt-engine-core. 🛡️
 */

const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Winston fallback para ambiente isolado
const governanceLogger = { log: (level, msg) => console.log(`[${level.toUpperCase()}] ${msg}`) };

const BASE_LOG_DIR = path.join(__dirname, '..', '..', 'logs');

async function ensureDir(dirPath) {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
}

function createExecutionContext() {
  return { execution_id: uuidv4(), started_at: new Date().toISOString() };
}

function createLogEntry(data) {
  return {
    ...data,
    timestamp: new Date().toISOString()
  };
}

async function writeLog({ execution_id, type = 'governance', data }) {
  const dir = path.join(BASE_LOG_DIR, type);
  await ensureDir(dir);
  const filePath = path.join(dir, `${execution_id}.log.json`);

  let logs = [];
  try {
    const existingContent = await fs.readFile(filePath, 'utf-8');
    logs = JSON.parse(existingContent);
  } catch (err) {}

  logs.push(data);
  await fs.writeFile(filePath, JSON.stringify(logs, null, 2));
}

async function logPromotionEvent({ execution_id, step, state, message, details = {} }) {
  await writeLog({ execution_id, type: 'promotion', data: { execution_id, step, state, message, details, timestamp: new Date().toISOString() } });
}

async function error(message, details = {}) {
  await writeLog({
    execution_id: details.execution_id || 'system',
    type: 'errors',
    data: { step: 'SYSTEM', phase: 'ERROR', error: details.error || { message }, timestamp: new Date().toISOString() }
  });
}

module.exports = {
  createExecutionContext,
  createLogEntry,
  logPromotionEvent,
  error,
  info: (msg) => console.log(`[INFO] ${msg}`)
};

/**
 * BOLT: Validator (Hard Enforcement)
 * Garante que o output dos agentes siga o Audit Schema e as regras da Skill.
 * Migrado para bolt-engine-core/utils/. 🛡️📏
 */

class BoltValidator {
  static validate(skillName, output) {
    console.log(`[BOLT:VALIDATOR] Validating output for skill: ${skillName}`);
    
    let result = {
      status: "success",
      hard_fails: 0,
      soft_fails: { low: 0, medium: 0, high: 0, total_accumulated: 0 },
      issues: []
    };

    try {
      if (!output.decision || !output.decision.summary || !output.decision.reason) {
        this._addIssue(result, "hard", null, "Mandatory 'decision' fields missing.");
      }

      switch(skillName) {
        case 'context_scanner': this._validateScanner(output, result); break;
        case 'po': this._validatePO(output, result); break;
        case 'architect': this._validateArchitect(output, result); break;
      }

      if (result.hard_fails > 0) result.status = "hard_fail";
      else if (result.soft_fails.high > 0 || result.soft_fails.medium > 0) result.status = "soft_fail";

      return result;
    } catch (err) {
      return { status: "failed", error: err.message };
    }
  }

  static _addIssue(result, type, severity, message) {
    if (type === "hard") {
      result.hard_fails++;
      result.issues.push({ type, message });
    } else {
      result.soft_fails[severity]++;
      if (severity === "high") result.soft_fails.total_accumulated++;
      result.issues.push({ type, severity, message });
    }
  }

  static _validateScanner(output, result) {
    const required = ['context_summary', 'entities', 'risks', 'confidence', 'contract_readiness'];
    for (const field of required) if (!output[field]) this._addIssue(result, "hard", null, `Missing field: ${field}`);
  }

  static _validatePO(output, result) {
    if (!output.refined_task) this._addIssue(result, "hard", null, "PO Skill missing refined_task.");
  }

  static _validateArchitect(output, result) {
    if (!output.technical_spec) this._addIssue(result, "hard", null, "Architect missing technical_spec.");
    if (!output.execution_plan) this._addIssue(result, "soft", "medium", "Architect missing 'execution_plan'.");
  }
}

module.exports = BoltValidator;

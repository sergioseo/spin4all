/**
 * BOLT: Global Promotion Lock (v8.0 Elite - Hybrid Resilience)
 * Orquestrador de Concorrência Distribuída. 🛡️⚖️🏗️🚀
 * 
 * Estratégia Híbrida:
 * 1. Primário: PostgreSQL Advisory Locks (Escala de Produção) 🔐
 * 2. Fallback: Redis Distributed Lock (Resiliência de Dev/Cloud) 🛰️
 */

const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });
const { Pool } = require('pg');
const Redis = require('ioredis');

// Configurações
const BOLT_PROMOTION_LOCK_ID = 941183;
const REDIS_LOCK_KEY = 'bolt:promotion:lock';
const REDIS_LOCK_TTL = 120000; // 2 minutos de timeout de segurança

// Conectores
const pgPool = new Pool({
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432'),
  database: process.env.DB_NAME,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  connectionTimeoutMillis: 2000 // Falha rápido se o DB estiver offline
});

const redis = new Redis({
  host: process.env.REDIS_HOST || '127.0.0.1',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD || null,
  retryStrategy: (times) => null // Não tenta reconectar eternamente no lock
});

let activeLockType = null;

async function acquireGlobalLock() {
  console.log(`[BOLT:LOCK] 📡 Tentando adquirir lock global...`);

  // --- TENTATIVA 1: POSTGRESQL (Tier 1) ---
  try {
    const client = await pgPool.connect();
    const { rows } = await client.query('SELECT pg_try_advisory_lock($1) as locked', [BOLT_PROMOTION_LOCK_ID]);
    client.release();
    
    if (rows[0].locked) {
      console.log(`[BOLT:LOCK] 🔒 Lock PG Adquirido (ID: ${BOLT_PROMOTION_LOCK_ID}).`);
      activeLockType = 'pg';
      return true;
    }
  } catch (err) {
    console.warn(`[BOLT:LOCK] ⚠️  Tier 1 (Postgres) indisponível: ${err.message}`);
  }

  // --- TENTATIVA 2: REDIS (Tier 2 Fallback) ---
  try {
    const locked = await redis.set(REDIS_LOCK_KEY, Date.now(), 'NX', 'PX', REDIS_LOCK_TTL);
    if (locked === 'OK') {
      console.log(`[BOLT:LOCK] 🛡️  Lock REDIS Adquirido (Resiliência Ativa).`);
      activeLockType = 'redis';
      return true;
    }
  } catch (err) {
    console.error(`[BOLT:LOCK] 🚨 Tier 2 (Redis) Falhou: ${err.message}`);
  }

  console.error(`[BOLT:LOCK] ❌ FALHA CRÍTICA: Nenhum sistema de lock disponível.`);
  return false;
}

async function releaseGlobalLock() {
  if (activeLockType === 'pg') {
    try {
      const client = await pgPool.connect();
      await client.query('SELECT pg_advisory_unlock($1)', [BOLT_PROMOTION_LOCK_ID]);
      client.release();
      console.log(`[BOLT:LOCK] 🔓 Lock PG Liberado.`);
    } catch (err) { console.error(`[BOLT:LOCK] ❌ Erro ao liberar PG: ${err.message}`); }
  } 
  else if (activeLockType === 'redis') {
    try {
      await redis.del(REDIS_LOCK_KEY);
      console.log(`[BOLT:LOCK] 🔓 Lock REDIS Liberado.`);
    } catch (err) { console.error(`[BOLT:LOCK] ❌ Erro ao liberar Redis: ${err.message}`); }
  }
  activeLockType = null;
}

async function runWithGlobalLock(taskFn) {
  const locked = await acquireGlobalLock();
  if (!locked) throw new Error('BLOQUEIO_CONCORRENCIA: Não foi possível garantir a atomicidade da promoção.');
  
  try {
    return await taskFn();
  } finally {
    await releaseGlobalLock();
  }
}

module.exports = { acquireGlobalLock, releaseGlobalLock, runWithGlobalLock };

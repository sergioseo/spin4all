/**
 * BOLT: Sandbox & Path Validator (v7.3 Elite)
 * Migrado para bolt-engine-core/utils/. 🛡️🏗️
 */

const path = require('path');
const fs = require('fs');

function validatePath(targetPath, baseDir) {
  const absoluteBase = path.resolve(baseDir);
  const absoluteTarget = path.resolve(targetPath);
  let resolvedTarget;
  try {
    if (fs.existsSync(absoluteTarget)) {
      resolvedTarget = fs.realpathSync(absoluteTarget);
    } else {
      const parentDir = path.dirname(absoluteTarget);
      if (fs.existsSync(parentDir)) {
        resolvedTarget = path.join(fs.realpathSync(parentDir), path.basename(absoluteTarget));
      } else {
        resolvedTarget = absoluteTarget;
      }
    }
  } catch (err) {
    resolvedTarget = absoluteTarget;
  }

  if (!resolvedTarget.startsWith(absoluteBase)) {
    const error = new Error(`🚨 BOLT SEGURIDADE: Tentativa de Escape de Sandbox Detectada!`);
    error.type = 'security_violation';
    error.details = { target: resolvedTarget, allowed_base: absoluteBase };
    throw error;
  }
  return resolvedTarget;
}

function isPathAllowed(filePath, allowedPaths = []) {
  if (!allowedPaths || allowedPaths.length === 0) return false;
  const normalizedPath = path.normalize(filePath).replace(/\\/g, '/');
  return allowedPaths.some(allowed => {
    const normAllowed = path.normalize(allowed).replace(/\\/g, '/');
    return normalizedPath === normAllowed || normalizedPath.startsWith(normAllowed + '/');
  });
}

function sanitizeFilename(filename) { return filename.replace(/[<>:"/\\|?*]/g, '_'); }

module.exports = { validatePath, isPathAllowed, sanitizeFilename };

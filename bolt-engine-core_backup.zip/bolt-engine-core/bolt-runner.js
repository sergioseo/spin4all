/**
 * BOLT: Runner (The Conductor v2.0 - Decoupled)
 * 
 * Orquestrador de alto nível focado em Governança e Promoção.
 * Independência total em relação ao TICO Toolkit.
 * ⚛️🏗️⚡⚙️🛡️
 */

const DeliberationController = require('./controllers/deliberation-controller');
const OrchestratorExecutor = require('./orchestrators/orchestrator-executor');
const logger = require('./utils/logger-bolt');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

class BoltRunner {
  constructor(skills, safeMode = 'full') {
    this.skills = skills;
    this.safeMode = safeMode;
    this.deliberator = new DeliberationController({
      skills,
      safe_mode: safeMode
    });
  }

  async run(userInput) {
    const executionId = uuidv4();
    console.log(`\n🚀 [BOLT:RUNNER] Starting governance pipeline: ${executionId}`);
    
    try {
      // 1. PHASE DELIBERATION (Brain)
      console.log(`🧠 [STAGE 1] Deliberating...`);
      let manifest = await this.deliberator.run(executionId, userInput);

      if (manifest.status === 'blocked' || manifest.status === 'escalated') {
        throw new Error(`Execution blocked by Deliberation: ${manifest.status}`);
      }

      // 🛡️ [STAGE 1.5] INTENT SANITIZER (Governança de Intenção)
      const IntentMediator = require('./services/intent-mediator');
      manifest = await IntentMediator.sanitize(manifest);

      if (manifest.status === 'awaiting_confirmation') {
        console.log(`\n🚨  [BOLT:PAUSE] MISSION REQUIRES HUMAN CONFIRMATION!`);
        console.log(`⚖️   Risk Level: ${manifest.decision_metrics?.risk_score * 100}%`);
        console.log(`\n🛑  Execution Paused. Awaiting user approval...`);
        return { executionId, status: 'awaiting_confirmation', manifest };
      }

      // 2. PHASE EXECUTION (Muscle)
      console.log(`⚔️ [STAGE 2] Executing steps in Sandbox (Draft)...`);
      // EXTRAÇÃO DE ELITE: Injetamos o execution_id no contrato técnico para garantir a rastreabilidade na Sandbox.
      const executionContract = { 
        ...(manifest.final_contract || manifest), 
        execution_id: executionId 
      };
      const executor = new OrchestratorExecutor(executionContract);
      await executor.execute();

      // NOTA: O QA Validator (TICO) não é mais chamado aqui. 
      // O BOLT confia na deliberação ou aguarda validação externa assíncrona.
      // 🛡️ [DECOUPLED] QA Check removed from core pipeline.

      // 3. PHASE PREPARATION (Staging)
      console.log(`🏗️ [STAGE 3] Preparing Staging for Approval...`);
      const prepResult = await executor.promoteService.prepare(manifest);

      if (!prepResult.success) {
        throw new Error(`Staging preparation failed: ${prepResult.error}`);
      }

      console.log(`\n⏸️  [BOLT:PAUSE] MISSION PREPARED IN STAGING!`);
      console.log(`📂  Release Path: ${prepResult.releasePath}`);
      console.log(`\n🚦  AWAITING COMMANDER APPROVAL TO GO LIVE.`);
      
      const humanReport = this._generateHumanReport(manifest);
      
      return {
        executionId,
        status: 'awaiting_promotion',
        releasePath: prepResult.releasePath,
        audit_report: humanReport
      };

    } catch (err) {
      console.error(`\n🚨 [BOLT:FAILURE] Pipeline broke:`, err.message);
      logger.error(`[BOLT:FAIL] ${executionId}`, { error: { message: err.message, stack: err.stack } });
      throw err;
    }
  }

  async approve(executionId, releasePath) {
    console.log(`\n🚀 [BOLT:COMMAND] Approval received for ${executionId}. Going LIVE!`);
    const PromoteService = require('./services/promote-service');
    const promoter = new PromoteService(executionId);
    return await promoter.commit(releasePath);
  }

  async reject(executionId, releasePath, reason = 'Rejeitado pelo Comandante') {
    console.log(`\n🛑 [BOLT:REJECT] Mission ${executionId} rejected.`);
    const PromoteService = require('./services/promote-service');
    const promoter = new PromoteService(executionId);
    return await promoter.moveToBacklog(releasePath, reason);
  }

  _generateHumanReport(manifest) {
    const risk = manifest.decision_metrics?.risk_score || 0;
    return {
      mission_summary: "Missão de Governança Estrutural",
      confidence: "Baseada em Deliberação Pura",
      risk_level: risk > 0.5 ? "ALTO" : "BAIXO",
      qa_status: "PENDENTE (Validação Externa TICO Requerida)"
    };
  }
}

module.exports = BoltRunner;

/**
 * BOLT: Redis Configuration (Central Hub)
 * Centraliza as configurações de rede para o BullMQ e Cache. 🛡️🛰️
 */

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

const redisConfig = {
  connection: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: process.env.REDIS_PORT || 6379,
    password: process.env.REDIS_PASSWORD || null
  },
  queueName: 'governance_queue'
};

module.exports = redisConfig;

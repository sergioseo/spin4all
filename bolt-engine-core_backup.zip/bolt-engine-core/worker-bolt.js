/**
 * BOLT: Worker (The Silent Engine)
 * Processa tarefas de governança de forma assíncrona via BullMQ. 🛡️🏗️
 */

const { Worker } = require('bullmq');
const BoltRunner = require('./bolt-runner');
const redisConfig = require('./config/redis-config');
const skills = require('./skills/deterministic-skills'); // Injetando Mock Skills para teste de infra
const logger = require('./utils/logger-bolt');

const worker = new Worker(
  redisConfig.queueName,
  async (job) => {
    const { executionId, input } = job.data;
    console.log(`\n📦 [BOLT:WORKER] Processing Job ${job.id} (Task: ${executionId})...`);
    
    try {
      // Injetamos as skills no construtor do Runner para evitar erro de undefined
      const runner = new BoltRunner(skills);
      const result = await runner.run(input);
      
      console.log(`✅ [BOLT:WORKER] Job ${job.id} completed successfully.`);
      return result;
    } catch (err) {
      console.error(`❌ [BOLT:WORKER] Job ${job.id} failed:`, err.message);
      logger.error(`[WORKER:FAIL] ${executionId}`, { error: err.message });
      throw err;
    }
  },
  {
    connection: redisConfig.connection,
    concurrency: 1 // Execução sequencial para garantir integridade atômica
  }
);

worker.on('ready', () => {
  console.log(`\n🛰️  [BOLT:WORKER] Engine ONLINE and listening to "${redisConfig.queueName}"...`);
});

worker.on('failed', (job, err) => {
  console.error(`\n🚨 [BOLT:ALARM] Job ${job?.id} failed with error: ${err.message}`);
});

module.exports = worker;

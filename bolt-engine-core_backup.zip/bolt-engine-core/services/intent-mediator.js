/**
 * BOLT: Intent Mediator (v10.0 Elite)
 * 
 * Camada de Governança Semântica.
 * Interpretador de intenções e aplicador de contratos seguros.
 * ⚛️🧠🛡️
 */

const logger = require('../utils/logger-bolt');

class IntentMediator {
  constructor() {
    this.name = 'INTENT_MEDIATOR';
    this.version = '1.0.0';
    this.policies = {
      'REMOVE_FIELD': { forbidden: ['DELETE'], mandatory: 'UPDATE', fallback_value: 'NULL' },
      'RESET_FIELD': { forbidden: ['DROP'], mandatory: 'UPDATE' }
    };
  }

  async sanitize(manifest) {
    console.log(`\n🔍 [BOLT:INTENT] Analyzing Intent Governance (v${this.version})...`);
    const originalAction = manifest.action || 'unknown';
    const originalIntent = manifest.intent || 'generic';

    if (this._isRemovalIntent(originalIntent)) {
      if (originalAction.toUpperCase().includes('DELETE ')) {
        console.log(`  🛡️  [INTENT:REWRITE] Detected dangerous DELETE. Applying Safe Rewriting...`);
        manifest.action = this._transformToDeleteToUpdateNull(originalAction);
        manifest.governance_note = "Safe Rewriting applied: DELETE transformed to UPDATE NULL.";
      }
    }

    return manifest;
  }

  _isRemovalIntent(intent) {
    const removalKeywords = ['deletar foto', 'remover bio', 'limpar campo', 'remover imagem'];
    return removalKeywords.some(k => intent.toLowerCase().includes(k));
  }

  _transformToDeleteToUpdateNull(sql) {
    const tableMatch = sql.match(/FROM\s+(\w+)/i);
    const whereMatch = sql.match(/WHERE\s+(.+)/i);
    if (tableMatch && whereMatch) {
      const table = tableMatch[1];
      const where = whereMatch[1];
      return `UPDATE ${table} SET profile_photo = NULL WHERE ${where}`;
    }
    return sql;
  }
}

module.exports = new IntentMediator();

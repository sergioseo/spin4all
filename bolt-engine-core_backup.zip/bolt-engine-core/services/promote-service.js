/**
 * BOLT: Promote Service (v13.6 Elite)
 * 
 * O "Coração" do Desmembramento. Responsável pela promoção transacional 
 * de código entre as camadas de governança e gestão de backlog.
 * 🏗️⚡⚙️🛡️
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');
const logger = require('../utils/logger-bolt');
const locks = require('../utils/promotion-lock');

// Configuração de Ambientes de Governança
// Nota: Em produção, estas pastas podem residir em volumes externos.
const BASE_SANDBOX = path.join(process.cwd(), 'scripts', 'bolt');
const MAX_RELEASES = 5;

const PROMOTION_STATES = {
  IDLE: 'IDLE',
  PREPARING: 'PREPARING',
  SYNCHRONIZING: 'SYNCHRONIZING',
  VALIDATING: 'VALIDATING',
  COMMITTING: 'COMMITTING',
  SWAPPING: 'SWAPPING',
  VERIFYING: 'VERIFYING',
  LIVE: 'LIVE',
  FAILED: 'FAILED'
};

class PromoteService {
  constructor(executionId) {
    if (!executionId) throw new Error('executionId é obrigatório para o PromoteService.');
    this.executionId = executionId;
    this.state = PROMOTION_STATES.IDLE;
    
    this.paths = {
      draft: path.join(BASE_SANDBOX, 'draft', executionId),
      staging: path.join(BASE_SANDBOX, 'staging', executionId),
      releases: path.join(BASE_SANDBOX, 'releases'),
      current: path.join(BASE_SANDBOX, 'current'),
      backups: path.join(BASE_SANDBOX, 'backups'),
      backlog: path.join(BASE_SANDBOX, 'backlog')
    };
  }

  calculateHash(dir) {
    if (!fs.existsSync(dir)) return null;
    const hash = crypto.createHash('sha256');
    this._getFilesRecursive(dir).sort().forEach(file => {
      hash.update(path.relative(dir, file));
      hash.update(fs.readFileSync(file));
    });
    return hash.digest('hex');
  }

  _getFilesRecursive(dir, files = []) {
    if (!fs.existsSync(dir)) return files;
    fs.readdirSync(dir).forEach(file => {
      const full = path.join(dir, file);
      if (fs.statSync(full).isDirectory()) {
        this._getFilesRecursive(full, files);
      } else {
        files.push(full);
      }
    });
    return files;
  }

  async syncToStaging() {
    this._transit(PROMOTION_STATES.SYNCHRONIZING);
    try {
      if (!fs.existsSync(this.paths.staging)) fs.mkdirSync(this.paths.staging, { recursive: true });
      fs.cpSync(this.paths.draft, this.paths.staging, { recursive: true, force: true });
    } catch (err) {
      throw new Error(`Falha na sincronização STAGING: ${err.message}`);
    }
  }

  async atomicSwap(releasePath) {
    this._transit(PROMOTION_STATES.SWAPPING);
    const winCurrent = path.normalize(this.paths.current);
    const winTarget = path.normalize(releasePath);

    try {
      if (fs.existsSync(this.paths.current)) {
        fs.rmSync(this.paths.current, { recursive: true, force: true });
      }
      // Comando para Windows (Junction)
      execSync(`cmd /c mklink /J "${winCurrent}" "${winTarget}"`);
      
      this._transit(PROMOTION_STATES.VERIFYING);
      const resolved = fs.realpathSync(this.paths.current);
      if (path.normalize(resolved) !== path.normalize(fs.realpathSync(releasePath))) {
        throw new Error(`Inconsistência de Junction!`);
      }
      this._transit(PROMOTION_STATES.LIVE);
    } catch (err) {
      this._transit(PROMOTION_STATES.FAILED);
      throw err;
    }
  }

  async prepare(manifest) {
    return await locks.runWithGlobalLock(async () => {
      try {
        await this.syncToStaging();
        this._transit(PROMOTION_STATES.VALIDATING);
        const currentHash = this.calculateHash(this.paths.staging);
        
        this._transit(PROMOTION_STATES.COMMITTING);
        const timestamp = Date.now();
        const releaseDir = path.join(this.paths.releases, `v_${timestamp}_${this.executionId.substring(0, 8)}`);
        
        if (!fs.existsSync(releaseDir)) fs.mkdirSync(releaseDir, { recursive: true });
        fs.cpSync(this.paths.staging, releaseDir, { recursive: true, force: true });

        return { success: true, releasePath: releaseDir, hash: currentHash };
      } catch (err) {
        this._transit(PROMOTION_STATES.FAILED);
        throw err;
      }
    });
  }

  async commit(releasePath) {
    return await locks.runWithGlobalLock(async () => {
      try {
        await this.atomicSwap(releasePath);
        this._cleanup();
        return { success: true, status: 'live' };
      } catch (err) {
        this._transit(PROMOTION_STATES.FAILED);
        throw err;
      }
    });
  }

  async moveToBacklog(releasePath, reason) {
    return await locks.runWithGlobalLock(async () => {
      try {
        if (!fs.existsSync(this.paths.backlog)) fs.mkdirSync(this.paths.backlog, { recursive: true });
        const backlogTarget = path.join(this.paths.backlog, path.basename(releasePath));
        fs.renameSync(releasePath, backlogTarget);
        fs.writeFileSync(path.join(backlogTarget, 'rejection.json'), JSON.stringify({ rejected_at: new Date().toISOString(), reason, execution_id: this.executionId }, null, 2));
        return { success: true, backlogPath: backlogTarget };
      } catch (err) {
        throw err;
      }
    });
  }

  _transit(newState) {
    console.log(`[BOLT:PROMOTE] [STATE] ${this.state} → ${newState}`);
    this.state = newState;
  }

  _cleanup() {
    if (!fs.existsSync(this.paths.releases)) return;
    const releases = fs.readdirSync(this.paths.releases)
      .filter(f => f.startsWith('v_'))
      .map(f => ({ name: f, path: path.join(this.paths.releases, f), time: fs.statSync(path.join(this.paths.releases, f)).mtime }))
      .sort((a, b) => b.time - a.time);

    if (releases.length > MAX_RELEASES) {
      releases.slice(MAX_RELEASES).forEach(r => fs.rmSync(r.path, { recursive: true, force: true }));
    }
  }
}

module.exports = PromoteService;

/**
 * BOLT Orchestrator Executor (Resilient Execution v1.0)
 * Consome o Master Manifest e executa o execution_plan.
 * ⚛️⚔️⚙️🛡️
 */

const logger = require('../utils/logger-bolt');
const PromoteService = require('../services/promote-service');
const sandbox = require('../utils/sandbox-validator');
const fs = require('fs');
const path = require('path');
const skillResolver = require('../skills/skill-resolver');
const skillLoader = require('../skills/skill-loader');

class OrchestratorExecutor {
  constructor(manifest) {
    this.manifest = manifest;
    this.executionId = manifest.execution_id;
    this.steps = manifest.execution_plan?.steps || [];
    this.promoteService = new PromoteService(this.executionId);
  }

  async execute() {
    console.log(`\n🛰️  [BOLT:EXECUTOR] Starting execution: ${this.executionId}`);
    
    let finalStatus = 'completed';
    for (const step of this.steps) {
      const result = await this._executeStep(step);
      if (result.status === 'failed') {
        finalStatus = 'failed';
        break;
      }
    }
    
    console.log(`\n🏁 [BOLT:EXECUTOR] Execution finished: ${this.executionId} | Status: ${finalStatus.toUpperCase()}`);
    return { status: finalStatus, execution_id: this.executionId };
  }

  async _executeStep(step) {
    const { order, action, scope } = step;
    console.log(`\n⚙️  [BOLT:EXECUTOR] Step ${order}: ${action} (${scope})`);

    try {
      await this._runAction(action, scope);
      return { status: 'success', step: order };
    } catch (err) {
      console.error(`  ❌ Step ${order} FAILED: ${err.message}`);
      return { status: 'failed', step: order };
    }
  }

  async _runAction(action, scope) {
    console.log(`    → [BOLT:SKILL] Resolving context for: ${scope}`);
    const skills = skillResolver.resolve(scope, action);
    const skillStack = skills.map(s => {
      try { return skillLoader.load(s); } catch (e) { return null; }
    }).filter(s => s !== null);

    return await this._executeIndustrialWrite(action, scope);
  }

  async _executeIndustrialWrite(action, scope) {
    if (!scope.startsWith('file:')) return { status: 'generic_success' };
    const relativeFilePath = scope.split('file:')[1];
    const draftPath = path.join(this.promoteService.paths.draft, relativeFilePath);
    
    // Sandbox Enforcement
    const validatedPath = sandbox.validatePath(draftPath, this.promoteService.paths.draft);
    
    fs.mkdirSync(path.dirname(validatedPath), { recursive: true });
    fs.writeFileSync(validatedPath, action);
    console.log(`    ✅ [DRAFT:SECURE] Written: ${relativeFilePath}`);
    return { status: 'write_success', path: validatedPath };
  }
}

module.exports = OrchestratorExecutor;

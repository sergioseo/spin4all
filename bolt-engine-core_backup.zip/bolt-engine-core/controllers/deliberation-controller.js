/**
 * BOLT: Deliberation Controller (Resilience Engine v2.7)
 * Orquestrador central da Camada de Resolução de Restrições.
 */

const fs = require('fs');
const path = require('path');
const validator = require('../utils/validator-bolt');
const logger = require('../utils/logger-bolt');

class DeliberationController {
  constructor({ skills, safe_mode = 'full' }) {
    this.skills = skills; 
    this.safe_mode = safe_mode;
    this.max_rounds = 2;
  }

  async run(executionId, input) {
    console.log(`\n⚖️ [BOLT:DELIBERATION] Starting execution: ${executionId} | Mode: ${this.safe_mode}`);
    let state = { execution_id: executionId, status: "in_progress", safe_mode: this.safe_mode, rounds: [], final_contract: null, weighted_confidence: 0, deliberation_history: { rounds_executed: 0, issues_resolved: [], strategy_shift: { occurred: false } } };

    try {
      const round1 = await this.executeRound(1, state, input);
      state.rounds.push(round1);
      state.deliberation_history.rounds_executed = 1;

      if (this.isConverged(round1)) return this.finish(state, "converged", round1.architect.output);

      const round2 = await this.executeRound(2, state, round1);
      state.rounds.push(round2);
      state.deliberation_history.rounds_executed = 2;

      if (this.isConverged(round2)) return this.finish(state, "converged", round2.architect.output);

      const finalStatus = this.getFinalStatus(round2);
      return this.finish(state, finalStatus, round2.architect.output);
    } catch (err) {
      console.error(`[BOLT:DELIBERATION] Critical failure:`, err.message);
      state.status = "escalated";
      state.error = err.message;
      return state;
    }
  }

  async executeRound(num, state, previousData) {
    console.log(`\n🔄 [BOLT:DELIBERATION] Executing Round ${num}...`);
    const architectOutput = (num === 1) ? await this.skills.architect.run(previousData) : await this.skills.architect.resolve(previousData);
    const archVal = validator.validate('architect', architectOutput);
    const scannerOutput = await this.skills.scanner.run(architectOutput);
    const scannerVal = validator.validate('context_scanner', scannerOutput);
    const poOutput = await this.skills.po.run(architectOutput);
    const poVal = validator.validate('po', poOutput);

    return { round: num, architect: { output: architectOutput, validation: archVal }, scanner: { output: scannerOutput, validation: scannerVal }, po: { output: poOutput, validation: poVal }, confidence: this.calculateConfidence(scannerOutput, poOutput, architectOutput) };
  }

  calculateConfidence(scanner, po, arch) {
    const s = (scanner.confidence?.overall || 0.8) * 0.4;
    const p = (po.confidence?.overall || 0.8) * 0.3;
    const a = (arch.confidence?.overall || 0.8) * 0.3;
    return parseFloat((s + p + a).toFixed(2));
  }

  isConverged(round) {
    const scanner = round.scanner.validation;
    const po = round.po.output;
    return (scanner.status === "success" && scanner.hard_fails === 0 && round.confidence > 0.8 && po.approved !== false);
  }

  getFinalStatus(round) {
    const val = round.scanner.validation;
    if (val.hard_fails > 0 || round.confidence < 0.6) return "blocked";
    if (val.soft_fails?.medium > 0 || val.status === "failed") return "degraded";
    return "converged";
  }

  finish(state, status, finalContract) {
    const lastRound = state.rounds[state.rounds.length - 1];
    state.status = status;
    state.final_contract = finalContract;
    state.weighted_confidence = lastRound.confidence;
    state.execution_constraints = this._getModeConstraints(state.safe_mode);
    state.decision_metrics = { confidence: state.weighted_confidence, risk_score: this._calculateRiskScore(state), impact_score: this._calculateImpactScore(finalContract.impact_scope || {}) };
    return state;
  }

  _calculateRiskScore(state) {
    let score = (state.soft_fails?.total_accumulated || 0) * 0.05;
    if (state.safe_mode === 'full') score += 0.2;
    return Math.min(parseFloat(score.toFixed(2)), 1.0);
  }

  _calculateImpactScore(scope) {
    let score = (scope.files?.length || 0) * 0.1;
    return Math.min(parseFloat(score.toFixed(2)), 1.0);
  }

  _getModeConstraints(mode) {
    const constraints = { blocked_paths: [], allowed_operations: ["all"] };
    if (mode === 'backend_only') constraints.blocked_paths = ["**/*.css", "**/*.html", "frontend/**/*"];
    return constraints;
  }
}

module.exports = DeliberationController;

/**
 * TICO: Avatar Generator (v12.1 Elite)
 * 
 * Serviço para geração de placeholders estéticos (Siglas).
 * Migrado para TICO Toolkit.
 * 🎨👤🚀
 */

const fs = require('fs');
const path = require('path');

class AvatarGenerator {
  constructor() {
    this.name = 'AVATAR_GENERATOR';
    this.version = '1.0.0';
    
    // Paleta de Cores Spin4all (Premium)
    this.colors = ['#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', '#10b981'];
    
    // O TICO agora precisa localizar a pasta 'public' do Portal.
    // Estratégia de Config: Prioriza ENV, caso contrário assume estrutura local (Fase 14.1)
    const defaultPublicPath = path.join(__dirname, '..', 'public', 'assets', 'avatars');
    this.asset_root = process.env.SPIN4ALL_PUBLIC_PATH || defaultPublicPath;
  }

  generate(fullName) {
    const initials = this._getInitials(fullName);
    const color = this._getRandomColor();
    const fileName = `avatar-${initials.toLowerCase()}-${Date.now()}.svg`;
    const fullPath = path.join(this.asset_root, fileName);

    // Garantir diretório
    try {
      if (!fs.existsSync(this.asset_root)) {
        fs.mkdirSync(this.asset_root, { recursive: true });
      }
    } catch (err) {
      console.error(`🚨 [TICO:AVATAR] Error creating directory: ${err.message}`);
      // Fallback para sandbox local no toolkit se o portal não estiver acessível
      const fallbackPath = path.join(__dirname, 'sandbox-avatars');
      if (!fs.existsSync(fallbackPath)) fs.mkdirSync(fallbackPath);
      return this.generateAt(fullName, fallbackPath);
    }

    const svg = `
      <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="${color}"/>
        <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-family="Arial, sans-serif" font-size="80" font-weight="bold">
          ${initials}
        </text>
      </svg>
    `;

    fs.writeFileSync(fullPath, svg.trim());
    console.log(`  🎨 [TICO:AVATAR] Placeholder created: ${fileName} (Initials: ${initials})`);
    
    return fileName;
  }

  // Método auxiliar para geração em pastas específicas (útil para o BOLT Staging)
  generateAt(fullName, targetPath) {
    const initials = this._getInitials(fullName);
    const color = this._getRandomColor();
    const fileName = `avatar-${initials.toLowerCase()}-${Date.now()}.svg`;
    const fullPath = path.join(targetPath, fileName);
    
    const svg = `
      <svg width="200" height="200" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
        <rect width="200" height="200" fill="${color}"/>
        <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-family="Arial, sans-serif" font-size="80" font-weight="bold">
          ${initials}
        </text>
      </svg>
    `;

    fs.writeFileSync(fullPath, svg.trim());
    return fileName;
  }

  _getInitials(name) {
    const stopwords = ['quero', 'que', 'mude', 'minha', 'foto', 'para', 'uma', 'do', 'da', 'com', 'no', 'perfil', 'avatar'];
    const parts = name.split(/\s+/)
      .filter(p => !stopwords.includes(p.toLowerCase()))
      .filter(p => p.length > 0);

    const capitalized = parts.filter(p => /^[A-Z]/.test(p));
    const target = capitalized.length > 0 ? capitalized : parts;

    return target
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2) || '??';
  }

  _getRandomColor() {
    return this.colors[Math.floor(Math.random() * this.colors.length)];
  }
}

module.exports = new AvatarGenerator();

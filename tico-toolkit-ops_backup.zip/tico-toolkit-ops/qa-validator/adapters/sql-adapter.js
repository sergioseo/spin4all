/**
 * TICO: SQL Adapter (v9.8 Elite)
 */
class SQLAdapter {
  constructor() {
    this.name = 'SQL_ELITE_ADAPTER';
    this.version = '1.0.0';
    this.weights = { syntax: 0.3, security: 0.6, style: 0.1 };
  }

  async validate(content) {
    const diagnosis = { syntax_score: 1.0, security_score: 1.0, style_score: 1.0, violations: [], auto_fixes: [] };
    const sql = content.toUpperCase();

    if (sql.includes('DELETE ') || sql.includes('UPDATE ')) {
      if (!sql.includes(' WHERE ')) {
        diagnosis.security_score = 0.0;
        diagnosis.violations.push('SECURITY_FATAL: DELETE or UPDATE command without WHERE clause detected!');
      }
    }

    if (sql.includes('DROP ') || sql.includes('TRUNCATE ')) {
      diagnosis.security_score = 0.0;
      diagnosis.violations.push('SECURITY_FATAL: DDL commands (DROP/TRUNCATE) are forbidden via standard pipeline.');
    }

    if (!content.trim().endsWith(';')) {
      diagnosis.syntax_score = 0.8;
      diagnosis.violations.push('SYNTAX_WARNING: SQL command should end with a semicolon (;)');
      diagnosis.auto_fixes.push({ type: 'syntax', action: 'add_semicolon', confidence: 0.99, content: content.trim() + ';' });
    }

    return diagnosis;
  }
}

module.exports = new SQLAdapter();

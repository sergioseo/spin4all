/**
 * TICO: QA Validator Core (v9.8 Elite)
 * 
 * Orquestrador central de qualidade e governança (Migrado para TICO Toolkit).
 * ⚛️🛡️📐🧬
 */

const fs = require('fs');
const path = require('path');

// No TICO, os adaptadores são carregados localmente
const ADAPTERS = {
  '.css': require('./adapters/css-adapter'),
  '.js': require('./adapters/js-adapter'),
  '.sql': require('./adapters/sql-adapter'),
  'assets': require('./adapters/asset-adapter')
};

class QAValidator {
  constructor(executionId, options = {}) {
    this.executionId = executionId;
    this.policy = options.policy || {
      min_health_score: 0.9,
      fatal_threshold: 1,
      warning_threshold: 3,
      mode: 'strict' 
    };
    this.version = '1.0.0';
  }

  async validateDrafts(manifest, draftRoot) {
    console.log(`\n🛡️  [TICO:QA] Starting validation for ${this.executionId} (v${this.version})`);
    
    const results = {
      overall_score: 1.0,
      passed: true,
      files: [],
      error: null
    };

    const filesToValidate = this._collectFiles(draftRoot);
    let totalWeightedScore = 0;

    for (const file of filesToValidate) {
      const ext = path.extname(file);
      const adapter = ADAPTERS[ext];
      
      if (!adapter) {
        console.warn(`  ⚠️  No adapter for suffix: ${ext}. Skipping validation for: ${path.basename(file)}`);
        continue;
      }

      const content = fs.readFileSync(file, 'utf8');
      const diagnosis = await adapter.validate(content);

      const assetDiagnosis = ADAPTERS['assets'].validate(content);
      if (assetDiagnosis.score < 1.0) {
        diagnosis.violations.push(...assetDiagnosis.violations);
        diagnosis.security_score = Math.min(diagnosis.security_score || 1.0, assetDiagnosis.score);
      }
      
      const w = adapter.weights;
      const fileScore = (diagnosis.syntax_score * w.syntax) + 
                        (diagnosis.security_score * w.security) + 
                        (diagnosis.style_score * w.style);

      if (diagnosis.auto_fixes.length > 0 && this.policy.mode !== 'strict') {
        this._applyAutoFixes(file, diagnosis.auto_fixes);
      }

      results.files.push({
        path: path.relative(draftRoot, file),
        score: fileScore.toFixed(2),
        violations: diagnosis.violations,
        status: fileScore >= this.policy.min_health_score ? 'success' : 'warning'
      });

      totalWeightedScore += fileScore;
    }

    results.overall_score = filesToValidate.length > 0 ? totalWeightedScore / filesToValidate.length : 1.0;
    
    const fatalErrors = results.files.reduce((acc, f) => acc + f.violations.filter(v => v.includes('FATAL')).length, 0);
    const warnings = results.files.reduce((acc, f) => acc + f.violations.length, 0) - fatalErrors;

    if (fatalErrors >= this.policy.fatal_threshold) results.passed = false;
    if (warnings >= this.policy.warning_threshold && this.policy.mode === 'strict') results.passed = false;
    if (results.overall_score < this.policy.min_health_score && this.policy.mode === 'strict') results.passed = false;

    if (!results.passed) {
      results.error = `QA Quality Gate Violated: Score ${results.overall_score.toFixed(2)}. ${fatalErrors} Fatal, ${warnings} Warnings.`;
    }

    console.log(`  📊 [TICO:QA] Diagnosis: Score ${results.overall_score.toFixed(2)} | Status: ${results.passed ? 'PASSED ✅' : 'FAILED ❌'}`);
    return results;
  }

  _collectFiles(dir, fileList = []) {
    if (!fs.existsSync(dir)) return fileList;
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const name = path.join(dir, file);
      if (fs.statSync(name).isDirectory()) {
        this._collectFiles(name, fileList);
      } else {
        fileList.push(name);
      }
    }
    return fileList;
  }

  _applyAutoFixes(filePath, fixes) {
    for (const fix of fixes) {
      if (fix.confidence > 0.9) {
        fs.writeFileSync(filePath, fix.content);
        console.log(`    🪄  [QA:AUTOFIX] Applied fix: ${fix.action} to ${path.basename(filePath)}`);
      }
    }
  }
}

module.exports = QAValidator;

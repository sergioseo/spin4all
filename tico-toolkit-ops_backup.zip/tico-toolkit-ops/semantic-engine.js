/**
 * TICO: Semantic Engine (v11.0 Elite)
 * 
 * Motor de Governança de Domínio (Migrado para TICO Toolkit).
 * Diferencia FIELD vs ENTITY e impõe a mística de segurança.
 * ⚛️🧠🛡️
 */

const fs = require('fs');
const path = require('path');

// O Tico agora é independente. Se o logger não estiver disponível, usamos console.
let logger;
try {
  // Tentativa de carregar logger externo se houver ponte, caso contrário console.
  logger = console;
} catch (e) {
  logger = console;
}

class SemanticEngine {
  constructor() {
    this.name = 'SEMANTIC_ENGINE';
    this.version = '1.0.0';
    
    // Caminhos de configuração - O Tico agora busca em sua própria base ou via ENV
    this.configPath = process.env.TICO_CONFIG_PATH || path.join(__dirname, 'config');
    
    // Inicialização segura dos registros
    this.registry = {};
    this.entityMap = {};
    this._loadConfigs();
  }

  _loadConfigs() {
    try {
      const registryPath = path.join(this.configPath, 'intent-registry.json');
      const entityMapPath = path.join(this.configPath, 'entity-map.json');
      
      if (fs.existsSync(registryPath)) {
        this.registry = JSON.parse(fs.readFileSync(registryPath, 'utf-8'));
      }
      if (fs.existsSync(entityMapPath)) {
        this.entityMap = JSON.parse(fs.readFileSync(entityMapPath, 'utf-8'));
      }
    } catch (err) {
      console.warn(`⚠️ [TICO:SEMANTIC] Configs not found at ${this.configPath}. Running in vanilla mode.`);
    }
  }

  async process(manifest, userInput) {
    console.log(`\n🧠 [TICO:SEMANTIC] Analyzing Domain Intention (v${this.version})...`);
    
    const detectedIntent = this._classifyIntent(userInput);
    const rule = this.registry[detectedIntent];

    if (!rule) {
      console.log(`  🎲 [SEMANTIC:UNKNOWN] Intent not explicitly registered. Proceeding with standard QA.`);
      return manifest;
    }

    const proposedAction = manifest.action || '';
    const operation = proposedAction.trim().split(/\s+/)[0].toUpperCase();

    console.log(`  🎯 Detected Intent: ${detectedIntent} (Scope: ${rule.scope})`);
    manifest.intent = detectedIntent;

    if (rule.scope === 'FIELD_LEVEL') {
      if (operation === 'DELETE') {
        console.log(`  🛡️  [SEMANTIC:OVERKILL] Detected entity DELETE for a FIELD mission!`);
        manifest.action = this._applySafeRewrite(proposedAction, rule);
        manifest.status = 'intercepted';
        manifest.semantic_log = `Safe Rewrite: DELETE rejected for Field intent. Converted to ${rule.rewrite_strategy}.`;
      }
    }

    if (rule.scope === 'ENTITY_LEVEL' && rule.requires_confirmation) {
      console.log(`  👤 [SEMANTIC:CONFIRMATION] Critical entity operation detected. Awaiting approval.`);
      manifest.status = 'awaiting_confirmation';
      manifest.risk_score = 0.95;
    }

    if (detectedIntent.includes('photo')) {
      this._validateAssetUrl(manifest);
    }

    return manifest;
  }

  _classifyIntent(text) {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('foto') || lowerText.includes('imagem')) {
      if (lowerText.includes('remover') || lowerText.includes('apagar') || lowerText.includes('deletar') || lowerText.includes('excluir')) {
        return 'remove_profile_photo';
      }
      return 'update_profile_photo';
    }

    if (lowerText.includes('bio') || lowerText.includes('perfil') || lowerText.includes('biografia')) return 'update_user_bio';
    if (lowerText.includes('deletar minha conta') || lowerText.includes('encerrar conta') || lowerText.includes('excluir conta')) return 'delete_user_account';
    
    return 'unknown';
  }

  _applySafeRewrite(sql, rule) {
    if (rule.rewrite_strategy === 'SET_NULL') {
      const table = rule.target_entity;
      const field = rule.target_field;
      const whereMatch = sql.match(/WHERE\s+(.+)/i);
      const whereClause = whereMatch ? whereMatch[0] : 'WHERE 1=0';

      return `UPDATE ${table} SET ${field} = NULL ${whereClause};`;
    }
    return sql;
  }

  _validateAssetUrl(manifest) {
    const action = manifest.action || '';
    const values = action.match(/'([^']+)'/g);
    
    if (values) {
      values.forEach(v => {
        const val = v.replace(/'/g, '');
        if (!val.includes('.') || val.length < 5) {
          console.log(`  ⚠️  [SEMANTIC:ASSET] Possible blind string detected: "${val}"`);
          manifest.warnings = manifest.warnings || [];
          manifest.warnings.push(`Blind asset string detected: ${val}. Verify source.`);
        }
      });
    }
  }
}

module.exports = new SemanticEngine();
